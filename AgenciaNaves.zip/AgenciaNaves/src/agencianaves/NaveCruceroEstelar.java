
package agencianaves;


public class NaveCruceroEstelar extends NaveEspacial{
     private int cantidadTripulacion; 

    public NaveCruceroEstelar(String nombre, int capacidadTripulacion, int lanzamiento, int cantidadTripulacion) {
        super(nombre, capacidadTripulacion, lanzamiento);
        setTripulacion(cantidadTripulacion);
    }

    
    public void setTripulacion(int tripulacion) {
        if (cantidadTripulacion > getCapacidadTripulacion()) {
            throw new IllegalArgumentException("La tripulación no puede ser mayor que la capacidad de pasajeros.");
        }
         this.cantidadTripulacion = cantidadTripulacion; 
    }
    
    
    @Override
    public void mostrarInformacion() {
        System.out.println("Crucero Estelar: Nombre: " + getNombre() + " Capacidad de tripulacion: " + getCapacidadTripulacion() + 
                           " Año de lanzamiento " + getLanzamiento() + " cantidad de pasajeros " + cantidadTripulacion);
    }
}
