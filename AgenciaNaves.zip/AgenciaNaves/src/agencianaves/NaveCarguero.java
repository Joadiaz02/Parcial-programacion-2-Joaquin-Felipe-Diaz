
package agencianaves;


public class NaveCarguero extends NaveEspacial{
    private int capacidadCarga;

    public NaveCarguero(String nombre, int capacidadTripulacion, int lanzamiento, int capacidadCarga) {
        super(nombre, capacidadTripulacion, lanzamiento);
        setCapacidadCarga(capacidadCarga); 
    }

    public void setCapacidadCarga(int capacidadCarga) {
        if (capacidadCarga < 100 || capacidadCarga > 500) {
            throw new IllegalArgumentException("La capacidad de carga debe ser de entre 100 y 500 toneladas.");
        }
        this.capacidadCarga = capacidadCarga;
    }

    public int getCapacidadCarga() {
        return capacidadCarga;
    }

    @Override
    public void iniciarExploracion() {
        System.out.println(getNombre() + " esta iniciando una mision.");
    }

    @Override
    public void mostrarInformacion() {
        System.out.println("Nave Carguero: Nombre: " + getNombre() + " Capacidad de tripulacion: " + getCapacidadTripulacion()+ " Año de lanzamiento: " + getLanzamiento() + " Capacidad de carga: " 
                + capacidadCarga + " toneladas");
    }
}
