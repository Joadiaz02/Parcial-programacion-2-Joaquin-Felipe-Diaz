
package agencianaves;


public class AgenciaNavesTest {

  
    public static void main(String[] args) {
        Agencia agencia = new Agencia();
        agregarNaves(agencia);
        
        System.out.println("Lista de naves: ");
        agencia.mostrarNaves();
        
        System.out.println("Iniciando exploración: ");
        agencia.iniciarExploracionDeNaves();
    }
    
private static void agregarNaves(Agencia agencia) {
        try {
            NaveEspacial crucero1 = new NaveCruceroEstelar("Crucero estelar de Messi", 1000, 2022, 100);
            agencia.agregarNave(crucero1);

            NaveEspacial carguero1 = new NaveCarguero("Galactica", 10, 2023, 300);
            agencia.agregarNave(carguero1);

            NaveEspacial naveExploracion1 = new NaveExploracion("Apollo 16", 8, 2030, TipoDeMision.INVESTIGACION);
            agencia.agregarNave(naveExploracion1);
            
            
            NaveEspacial carguero2 = new NaveCarguero("Galactica", 100, 2023, 200);
            agencia.agregarNave(carguero2); 

        } catch (NaveDuplicadaException e) {
            System.out.println(e.getMessage()); 
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage()); 
        }
    }
}
